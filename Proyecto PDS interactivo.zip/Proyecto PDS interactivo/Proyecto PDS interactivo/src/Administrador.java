public class Administrador {

    private String correoInst;

    public void setCorreoInst (String correoInst){
        this.correoInst = correoInst;
    }

}
