import java.util.Scanner;
import java.util.ArrayList;

public class SmartTime{
  
  static private ArrayList<Integer> respuestas = new ArrayList<>();
  static private ArrayList<String> preguntasGT = new ArrayList<>();
  static private ArrayList<String> preguntasHS = new ArrayList<>();
  static private ArrayList<String[]> recomendacionesGT = new ArrayList<>();
  static public String[] maloGT = {"\n----------MAlO----------","\n1. Prioriza tus tareas:Identifica las tareas más importantes y urgentes, y concéntrate en completarlas primero. Utiliza técnicas como la matriz de Eisenhower para distinguir entre lo importante y lo urgente.", "\n2. Establece metas claras: Define metas realistas y específicas para cada día, semana o mes. Esto te ayudará a mantenerte enfocado y a dirigir tus esfuerzos hacia lo que realmente importa.", "\n3. Utiliza herramientas de planificación: Aprovecha herramientas como agendas, aplicaciones de gestión del tiempo o técnicas de organización para planificar y seguir tus actividades diarias.", "\n4. Elimina las distracciones: Identifica las distracciones comunes que te hacen perder el tiempo y trata de eliminarlas o minimizarlas. Esto puede incluir el uso excesivo de redes sociales, notificaciones de correo electrónico o interrupciones constantes.", "\n5. Practica la disciplina personal: Cultiva hábitos de disciplina personal, como la capacidad de decir no a tareas que no contribuyen a tus objetivos, el establecimiento de límites de tiempo para cada tarea y la capacidad de mantenerte enfocado en una tarea a la vez." };
  static public String[] regularGT = {"\n----------REGULAR----------", "\n1. Refina tus técnicas de planificación: Evalúa tus métodos actuales de planificación y busca formas de mejorarlos. Puede ser utilizando técnicas más avanzadas de organización o ajustando tu proceso de planificación para que sea más eficiente.", "\n2. Optimiza tu agenda:Revisa tu agenda regularmente para asegurarte de que estás asignando tiempo suficiente para cada tarea y actividad. Ajusta tu agenda según sea necesario para garantizar un equilibrio adecuado entre trabajo, descanso y recreación.","\n3. Mejora tu habilidad para delegar:Siempre que sea posible, delega tareas que no requieran tu atención personal. Esto te permitirá concentrarte en las actividades que realmente requieren tu experiencia y habilidades únicas.","\n4. Implementa técnicas de gestión del tiempo avanzadas: Explora técnicas más avanzadas de gestión del tiempo, como la técnica Pomodoro, la planificación inversa o el batching de tareas similares, para aumentar tu productividad y eficiencia.","\n5. Mantén el equilibrio:Asegúrate de mantener un equilibrio saludable entre el trabajo, la familia, el ocio y el autocuidado. No sacrifiques tu bienestar personal por el trabajo, y encuentra formas de integrar actividades que te traigan alegría y satisfacción en tu rutina diaria."};
  static public String[] buenoGT = {"\n----------BUENO----------", "\n1.Busca la optimización continua: Aunque ya seas excelente en la gestión del tiempo, siempre hay margen para mejorar. Continúa buscando formas de optimizar tu proceso de planificación y ejecución para aumentar tu eficiencia y productividad aún más.","\n2. Fomenta la creatividad y la innovación: Dedica tiempo a actividades que fomenten la creatividad y la innovación en tu trabajo. Esto puede incluir la exploración de nuevas ideas, la experimentación con diferentes enfoques o la colaboración con otros profesionales.","\n3. Desarrolla habilidades de liderazgo: Si aún no lo has hecho, considera desarrollar tus habilidades de liderazgo para poder influir y motivar a otros en la gestión del tiempo y la productividad. Esto puede incluir habilidades de comunicación, delegación y resolución de problemas.", "\n4. Mantén un enfoque en el crecimiento personal: Continúa invirtiendo en tu crecimiento personal y educativo mediante la adquisición de nuevas habilidades, la participación en programas de desarrollo profesional o la búsqueda de oportunidades de aprendizaje continuo.","\n5. Comparte tu conocimiento: Considera compartir tus conocimientos y experiencia en gestión del tiempo con otros a través de la mentoría, la escritura de blogs, la impartición de talleres o la participación en comunidades académicas. Ayudar a otros a mejorar su gestión del tiempo puede ser gratificante y significativo."};
  static public ArrayList<String[]> recomendacionesHS = new ArrayList<>();
  static public String[] maloHS = {"\n----------MALO----------","\n1. Establece una rutina de sueño: Intenta acostarte y levantarte a la misma hora todos los días, incluso los fines de semana. Esto ayuda a regular tu reloj interno y a mejorar la calidad del sueño. ", "\n2. Reduce la exposición a pantallas antes de dormir: Si estás usando dispositivos tecnológicos antes de acostarte, intenta reducir esta práctica al menos una hora antes de dormir. La luz azul emitida por las pantallas puede interferir con la producción de melatonina, la hormona responsable de regular el sueño.", "\n3. Practica la relajación antes de dormir: Dedica tiempo a actividades relajantes antes de acostarte, como leer un libro, tomar un baño caliente o practicar técnicas de respiración profunda. Esto puede ayudar a preparar tu mente y cuerpo para dormir.", "\n4. Cuida tu ambiente de sueño: Asegúrate de que tu habitación sea un entorno propicio para dormir. Mantén la habitación oscura, fresca y tranquila. Considera el uso de tapones para los oídos o una máscara para dormir si el ruido o la luz te molestan.", "\n5. Limita el consumo de cafeína y alcohol: Evita consumir cafeína y alcohol varias horas antes de acostarte, ya que pueden interferir con la calidad del sueño. Opta por bebidas relajantes como la leche tibia o la infusión de manzanilla antes de dormir." };
  static public String[] regularHS = {"\n----------REGULAR----------","\n1. Optimiza tu rutina de sueño: Aunque ya mantengas un horario regular de sueño, asegúrate de que estés durmiendo la cantidad adecuada de horas para tus necesidades individuales. Si sientes que todavía estás fatigado durante el día, considera ajustar tu horario de sueño para asegurarte de obtener suficiente descanso. ", "\n2. Mejora la calidad de tu sueño: Además de dormir la cantidad adecuada de horas, también es importante garantizar la calidad del sueño. Trata de crear un ambiente de dormitorio que sea lo más cómodo y relajante posible, y considera invertir en un colchón de calidad si es necesario. ", "\n3. Evita el estrés antes de dormir: Si bien puedes ser un poco cuidadoso en tu horario de sueño, el estrés y la ansiedad pueden interferir con tu capacidad para conciliar el sueño. Dedica tiempo antes de acostarte a actividades relajantes como la meditación, el yoga o la lectura para ayudar a calmar tu mente y prepararte para dormir.","\n4. Mantén un estilo de vida saludable: El ejercicio regular y una dieta equilibrada también pueden contribuir a mejorar la calidad del sueño. Intenta hacer ejercicio regularmente durante el día, pero evita hacerlo demasiado cerca de la hora de acostarte, ya que puede tener un efecto estimulante en tu cuerpo.","\n5. Limita el consumo de estimulantes: Aunque puedas ser medianamente bueno en tus hábitos de sueño, el consumo excesivo de cafeína, alcohol y nicotina puede afectar la calidad de tu sueño. Intenta limitar estos estimulantes, especialmente por la tarde y la noche, para garantizar un sueño reparador."};
  static public String[] buenoHS = {"\n----------BUENO----------","\n1.Mantén la consistencia: Sigue manteniendo un horario regular de sueño, acostándote y levantándote a la misma hora todos los días, incluso los fines de semana. La consistencia ayuda a regular tu reloj interno y a optimizar la calidad del sueño.","\n2.Perfecciona tu entorno de sueño: Asegúrate de que tu dormitorio sea un santuario para el sueño, libre de distracciones y diseñado para la máxima comodidad. Controla la temperatura, la luz y el ruido para crear un ambiente óptimo para dormir.", "\n3.Practica técnicas de relajación avanzadas: Explora técnicas avanzadas de relajación, como la meditación profunda, la visualización guiada o la atención plena, para calmar aún más tu mente y prepararte para un sueño reparador.","\n4.Optimiza tu estilo de vida: Continúa manteniendo un estilo de vida saludable, incluyendo ejercicio regular, una dieta equilibrada y la gestión efectiva del estrés. Estos hábitos promueven la salud general y contribuyen a un sueño de calidad.", "\n5. Prioriza el autocuidado: Reconoce la importancia del autocuidado en tu rutina diaria y reserva tiempo para actividades que fomenten el bienestar físico, mental y emocional. Esto puede incluir masajes, baños relajantes, hobbies gratificantes o simplemente tomarse un tiempo para disfrutar de la tranquilidad"};
  static private Scanner sc = new Scanner(System.in);

  public static void main (String[] args){
    
    System.out.println("\n-----------Bienvenido a SmarTime-----------");
    System.out.println("\nIngrese su rol (estudiante o administrador)");
    String rol; 
    rol = sc.nextLine();

    String p1, p2, p3, p4;
    p1 = "\n1. En una escala del 1 al 5 ¿XXXXX?";
    preguntasGT.add(p1);
    p2 = "\n2. En una escala del 1 al 5 ¿XXXXX?";
    preguntasGT.add(p2);
    p3 = "\n3. En una escala del 1 al 5 ¿XXXXX?";
    preguntasGT.add(p3);
    p4 = "\n4. En una escala del 1 al 5 ¿XXXXX?";
    preguntasGT.add(p4);

    p1 = "\n1. En una escala del 1 al 5 ¿XXXXX?";
    preguntasHS.add(p1);
    p2 = "\n2. En una escala del 1 al 5 ¿XXXXX?";
    preguntasHS.add(p2);
    p3 = "\n3. En una escala del 1 al 5 ¿XXXXX?";
    preguntasHS.add(p3);
    p4 = "\n4. En una escala del 1 al 5 ¿XXXXX?";
    preguntasHS.add(p4);

    recomendacionesGT.add(maloGT);
    recomendacionesGT.add(regularGT);
    recomendacionesGT.add(buenoGT);
    recomendacionesHS.add(maloHS);
    recomendacionesHS.add(regularHS);
    recomendacionesHS.add(buenoHS);

    if (rol.equalsIgnoreCase("estudiante")){
      
      System.out.println("\nIngresa tu nombre completo");
      String name;
      name = sc.nextLine();

      System.out.println("Ingresa tu edad");
      int age = sc.nextInt();

      crearUsuarioEstudiante(name, age);
    
      System.out.println("\n¡Hola "+name+" ¿Qué te gustaria mejorar?");
      System.out.println("1. Gestion del Tiempo");
      System.out.println("2. Horario de Sueño");
      System.out.println("\nIngresa la opcion que deseas realizar: ");
      sc.nextLine();
      int opcion;
      opcion = sc.nextInt();

      switch (opcion){
        case 1:
          System.out.println("\n¡Bienvenido a Gestion Del Tiempo!");
          System.out.println("A continuacion te realizaremos algunas preguntas para realizar un diagnostico sobre tu estado actual, y asi poder darte algunas recomendaciones.");
          
          int r1, r2, r3, r4;
      
          do{
            System.out.println(preguntasGT.get(0));
            r1= sc.nextInt();
            if (r1 < 1 || r1 > 5){
              System.out.println("Ingresa un valor valido");
            }
          } while (r1 < 1 || r1 > 5);
          
          do{
            System.out.println(preguntasGT.get(1));
            r2= sc.nextInt();
            if (r2 < 1 || r2 > 5){
              System.out.println("Ingresa un valor valido");
            }
          } while (r2 < 1 || r2 > 5);

          do{
            System.out.println(preguntasGT.get(2));
            r3= sc.nextInt();
            if (r3 < 1 || r3 > 5){
              System.out.println("Ingresa un valor valido");
            }
          } while (r3 < 1 || r3 > 5);

          do{
            System.out.println(preguntasGT.get(3));
            r4= sc.nextInt();
            if (r4 < 1 || r4 > 5){
              System.out.println("Ingresa un valor valido");
            }
          } while (r4 < 1 || r4 > 5);
      
          respuestas.add(r1);
          respuestas.add(r2);
          respuestas.add(r3); 
          respuestas.add(r4);
          
          int acum = 0;
          for (Integer r : respuestas) {
            acum = acum + r;
          }

          float promedio = acum/4;

          System.out.println("\n¡Muy Bien!");
          System.out.println("\nGracias " + name + " por utilizar este servicio.");
          System.out.println("\nSegun los resultados de la encuesta se obtuvo el siguiente diagnostico.");

          if (promedio >= 1 && promedio <=  1.666f){

            for (String string : maloGT) {
              if (string != null)
              System.out.println(string);
            }
            
          } else if (promedio > 1.666f && promedio <= 3.332f){
            
            for (String string : regularGT) {
              if (string != null)
              System.out.println(string);
            }

          } else if (promedio > 3.332f && promedio <= 5){            
            for (String string : buenoGT) {
              if (string != null)
              System.out.println(string);
            }
          }
        break;
        
        case 2:
          System.out.println("\n¡Bienvenido a Horario de Sueño!");
          System.out.println("A continuacion te realizaremos algunas preguntas para realizar un diagnostico sobre tu estado actual, y asi poder darte algunas recomendaciones.");

          do{
            System.out.println(preguntasHS.get(0));
            r1= sc.nextInt();
            if (r1 < 1 || r1 > 5){
              System.out.println("Ingresa un valor valido");
            }
          } while (r1 < 1 || r1 > 5);
          
          do{
            System.out.println(preguntasHS.get(1));
            r2= sc.nextInt();
            if (r2 < 1 || r2 > 5){
              System.out.println("Ingresa un valor valido");
            }
          } while (r2 < 1 || r2 > 5);

          do{
            System.out.println(preguntasHS.get(2));
            r3= sc.nextInt();
            if (r3 < 1 || r3 > 5){
              System.out.println("Ingresa un valor valido");
            }
          } while (r3 < 1 || r3 > 5);

          do{
            System.out.println(preguntasHS.get(3));
            r4= sc.nextInt();
            if (r4 < 1 || r4 > 5){
              System.out.println("Ingresa un valor valido");
            }
          } while (r4 < 1 || r4 > 5);
      
          respuestas.add(r1);
          respuestas.add(r2);
          respuestas.add(r3); 
          respuestas.add(r4);
          
          int acum1 = 0;
          
          for (Integer r : respuestas) {
            acum1 = acum1 + r;
          }

          float promedio1 = acum1/4;

          System.out.println("\n¡Muy Bien!");
          System.out.println("\nGracias " + name + " por utilizar este servicio.");
          System.out.println("\nSegun los resultados de la encuesta se obtuvo el siguiente diagnostico.");

          if (promedio1 >= 1 && promedio1 <=  1.666f){

            for (String string : maloHS) {
              if (string != null)
              System.out.println(string);
            }
            
          } else if (promedio1 > 1.666f && promedio1 <= 3.332f){

            for (String string : regularHS) {
              if (string != null)
              System.out.println(string);
            }

          } else if (promedio1 > 3.332f && promedio1 <= 5){
            
            for (String string : buenoHS) {
              if (string != null)
              System.out.println(string);
            }
          }
        break;
      }
    } else if (rol.equalsIgnoreCase("administrador")){
        System.out.println("Ingresa tu correo institucional");
    
        String correoInst = sc.nextLine();

        String c1,c2,c3,c4;
        c1 = "smazog@eafit.edu.co";
        c2 = "afveleza@eafit.edu.co";
        c3 = "jpduqueo@eafit.edu.co";
        c4 = "mrestrepa1@eafit.edu.co";
    
        if (correoInst.equals(c1) || correoInst.equals(c2) || correoInst.equals(c3) || correoInst.equals(c4)){
          crearUsuarioAdministrador(correoInst);
          
          System.out.println("\n¡Bienvenido Admin!");
          System.out.println("\n¿Que deseas modificar?");
          System.out.println("1. Gestion del Tiempo");
          System.out.println("2. Horario del Sueño");
          System.out.println("3. Salir");
          System.out.println("\nIngresa la opcion que deseas realizar: ");
          int opcion = sc.nextInt();
      
          switch (opcion){
            case 1:
              System.out.println("\n¿Que deseas modificar?");
              System.out.println("1. Preguntas");
              System.out.println("2. Recomendaciones");
              System.out.println("3. Salir");
              System.out.println("\nIngresa la opcion que deseas realizar: ");
              opcion = sc.nextInt();
          
              switch (opcion){
                case 1:
                  System.out.println("\nIngrese que desea realizar con las preguntas");
                  System.out.println("1. Editar Preguntas");
                  System.out.println("2. Eliminar Preguntas");
                  System.out.println("\nIngresa la opcion que deseas realizar: ");
                  opcion = sc.nextInt();
                  
                  switch (opcion){
                    case 1:
                      System.out.println("\nLas preguntas son:");
                      for (String string : preguntasGT) { 
                        System.out.println(string);  
                      }
                      sc.nextLine();

                      System.out.println("\nIngrese el numero de la pregunta que desea editar");
                      int pregunta = sc.nextInt();

                      System.out.println("\nIngrese la pregunta editada");
                      sc.nextLine();
                      String preguntaedit;
                      preguntaedit= sc.nextLine();
                      preguntaedit = "\n"+ preguntaedit;

                      preguntasGT.set((pregunta-1), preguntaedit);
                      
                      System.out.println("\nLas recomendaciones editadas son:");
                      for (String string : preguntasGT) {
                        System.out.println(string);
                      }
                      main(args);
                    break;

                    case 2:
                      System.out.println("Las preguntas son:");
                      for (String string : preguntasGT) { 
                        System.out.println(string);  
                      }
                      sc.nextLine();

                      System.out.println("\nIngrese el numero de la pregunta que desea eliminar");
                      pregunta = sc.nextInt();

                      preguntasGT.remove((pregunta-1));
                      
                      System.out.println("Las preguntas actualizadas son:");
                      for (String string : preguntasGT) {
                        System.out.println(string);
                      }

                      sc.nextLine();
                      main(args);
                    break;
                  }
                break;
                case 2:
                  System.out.println("\nIngrese que desea realizar con las recomendaciones");
                  System.out.println("1. Editar Recomendaciones");
                  System.out.println("2. Eliminar Recomendaciones");
                  System.out.println("3. Salir");
                  System.out.println("\nIngresa la opcion que deseas realizar: ");
                  opcion = sc.nextInt();
                  
                  switch (opcion){
                    case 1:
                      System.out.println("Las recomendaciones son:");
                      for (String[] string : recomendacionesGT) { 
                        for (String string2 : string) {
                          System.out.println(string2);
                        }    
                      }
                      sc.nextLine();
                      System.out.println("\nIngrese el estado que desea editar");
                      String estado = sc.nextLine();

                      if (estado.equalsIgnoreCase("Malo")){
                        for (String string : maloGT) {
                          System.out.println(string);
                        }

                        System.out.println("\nIngrese el numero de recomendacion que quiere editar");
                        opcion = sc.nextInt();
                        System.out.println("\nIngrese la recomendacion editada");
                        sc.nextLine();
                        String recomendacionedit;
                        recomendacionedit= sc.nextLine();

                        maloGT[(opcion + 2)] = recomendacionedit;
                        
                        System.out.println("Las recomendaciones editadas son:");
                        for (String string : maloGT) {
                          System.out.println(string);
                        }
                        main(args);
                      }

                      if (estado.equalsIgnoreCase("Regular")){
                        for (String string : regularGT) {
                          System.out.println(string);
                        }

                        System.out.println("\nIngrese el numero de recomendacion que quiere editar");
                        opcion = sc.nextInt();
                        System.out.println("\nIngrese la recomendacion editada");
                        sc.nextLine();
                        String recomendacionedit;
                        recomendacionedit= sc.nextLine();

                        regularGT[(opcion + 2)] = recomendacionedit;
                        
                        System.out.println("Las recomendaciones editadas son:");
                        for (String string : regularGT) {
                          System.out.println(string);
                        }
                        main(args);
                      }

                      if (estado.equalsIgnoreCase("Bien")){
                        for (String string : buenoGT) {
                          System.out.println(string);
                        }

                        System.out.println("\nIngrese el numero de recomendacion que quiere editar");
                        opcion = sc.nextInt();
                        System.out.println("\nIngrese la recomendacion editada");
                        sc.nextLine();
                        String recomendacionedit;
                        recomendacionedit= sc.nextLine();

                        buenoGT[(opcion + 2)] = recomendacionedit;
                        
                        System.out.println("Las recomendaciones editadas son:");
                        for (String string : buenoGT) {
                          System.out.println(string);
                        }
                        main(args);
                      }
                    break;
                    case 2:
                      System.out.println("Las recomendaciones son:");
                      for (String[] string : recomendacionesGT) { 
                        for (String string2 : string) {
                          System.out.println(string2);
                        }    
                      }
                      sc.nextLine();
                      System.out.println("\nIngrese el estado que desea eliminar");
                      estado = sc.nextLine();

                      if (estado.equalsIgnoreCase("Malo")){
                        for (String string : maloGT) {
                          System.out.println(string);
                        }

                        System.out.println("\nIngrese el numero de recomendacion que quiere eliminar");
                        opcion = sc.nextInt();

                        maloGT[(opcion + 2)] =null;
                        
                        System.out.println("Las recomendaciones actualizadas son:");
                        for (String string : maloGT) {
                          if (string != null)
                          System.out.println(string);
                        }
                        sc.nextLine();
                        main(args);
                      }

                      if (estado.equalsIgnoreCase("Regular")){
                        for (String string : regularGT) {
                          System.out.println(string);
                        }

                        System.out.println("\nIngrese el numero de recomendacion que quiere eliminar");
                        opcion = sc.nextInt();

                        regularGT[(opcion + 2)] =null;
                        
                        System.out.println("Las recomendaciones actualizadas son:");
                        for (String string : regularGT) {
                          if (string != null)
                          System.out.println(string);
                        }
                        sc.nextLine();
                        main(args);
                      }

                      if (estado.equalsIgnoreCase("Bien")){
                        for (String string : buenoGT) {
                          System.out.println(string);
                        }

                        System.out.println("\nIngrese el numero de recomendacion que quiere eliminar");
                        opcion = sc.nextInt();

                        buenoGT[(opcion + 2)] =null;
                        
                        System.out.println("Las recomendaciones actualizadas son:");
                        for (String string : buenoGT) {
                          if (string != null)
                          System.out.println(string);
                        }
                        sc.nextLine();
                        main(args);
                      }
                    break;

                    case 3: 
                    break;
                  }
                break;
                case 3:
                break;
              }
            break;

            case 2:
              System.out.println("\n¿Que deseas modificar?");
              System.out.println("1. Preguntas");
              System.out.println("2. Recomendaciones");
              System.out.println("\nIngresa la opcion que deseas realizar: ");
              opcion = sc.nextInt();
            
              switch (opcion){
                case 1:
                  System.out.println("\nIngrese que desea realizar con las preguntas");
                  System.out.println("1. Editar Preguntas");
                  System.out.println("2. Eliminar Preguntas");
                  System.out.println("\nIngresa la opcion que deseas realizar: ");
                  opcion = sc.nextInt();
                  
                  switch (opcion){
                    case 1:
                      System.out.println("Las preguntas son:");
                      for (String string : preguntasHS) { 
                        System.out.println(string);  
                      }
                      sc.nextLine();

                      System.out.println("\nIngrese el numero de la pregunta que desea editar");
                      int pregunta = sc.nextInt();

                      System.out.println("\nIngrese la pregunta editada");
                      sc.nextLine();
                      String preguntaedit;
                      preguntaedit= sc.nextLine();
                      preguntaedit = "\n"+preguntaedit;

                      preguntasHS.set((pregunta-1), preguntaedit);
                      
                      System.out.println("Las recomendaciones editadas son:");
                      for (String string : preguntasHS) {
                        System.out.println(string);
                      }
                      main(args);
                    break;
                    case 2:
                      System.out.println("Las preguntas son:");
                      for (String string : preguntasHS) { 
                        System.out.println(string);  
                      }
                      sc.nextLine();

                      System.out.println("\nIngrese el numero de la pregunta que desea eliminar");
                      pregunta = sc.nextInt();

                      preguntasHS.remove((pregunta-1));
                      
                      System.out.println("Las preguntas actualizadas son:");
                      for (String string : preguntasHS) {
                        System.out.println(string);
                      }

                      sc.nextLine();
                      main(args);
                    break;
                  }
                break;
                case 2:
                System.out.println("\nIngrese que desea realizar con las recomendaciones");
                System.out.println("1. Editar Recomendaciones");
                System.out.println("2. Eliminar Recomendaciones");
                System.out.println("3. Salir");
                System.out.println("\nIngresa la opcion que deseas realizar: ");
                opcion = sc.nextInt();
                
                switch (opcion){
                  case 1:
                    System.out.println("Las recomendaciones son:");
                    for (String[] string : recomendacionesHS) { 
                      for (String string2 : string) {
                        System.out.println(string2);
                      }    
                    }
                    sc.nextLine();
                    System.out.println("\nIngrese el estado que desea editar");
                    String estado = sc.nextLine();

                    if (estado.equalsIgnoreCase("Malo")){
                      for (String string : maloHS) {
                        System.out.println(string);
                      }

                      System.out.println("\nIngrese el numero de recomendacion que quiere editar");
                      opcion = sc.nextInt();
                      System.out.println("\nIngrese la recomendacion editada");
                      sc.nextLine();
                      String recomendacionedit;
                      recomendacionedit= sc.nextLine();

                      maloHS[(opcion + 2)] = recomendacionedit;
                      
                      System.out.println("Las recomendaciones editadas son:");
                      for (String string : maloHS) {
                        System.out.println(string);
                      }
                      main(args);
                    }

                    if (estado.equalsIgnoreCase("Regular")){
                      for (String string : regularHS) {
                        System.out.println(string);
                      }

                      System.out.println("\nIngrese el numero de recomendacion que quiere editar");
                      opcion = sc.nextInt();
                      System.out.println("\nIngrese la recomendacion editada");
                      sc.nextLine();
                      String recomendacionedit;
                      recomendacionedit= sc.nextLine();

                      regularHS[(opcion + 2)] = recomendacionedit;
                      
                      System.out.println("Las recomendaciones editadas son:");
                      for (String string : regularHS) {
                        System.out.println(string);
                      }
                      main(args);
                    }

                    if (estado.equalsIgnoreCase("Bien")){
                      for (String string : buenoHS) {
                        System.out.println(string);
                      }

                      System.out.println("\nIngrese el numero de recomendacion que quiere editar");
                      opcion = sc.nextInt();
                      System.out.println("\nIngrese la recomendacion editada");
                      sc.nextLine();
                      String recomendacionedit;
                      recomendacionedit= sc.nextLine();

                      buenoHS[(opcion + 2)] = recomendacionedit;
                      
                      System.out.println("Las recomendaciones editadas son:");
                      for (String string : buenoHS) {
                        System.out.println(string);
                      }
                      main(args);
                    }


                  break;
                  case 2:
                  System.out.println("Las recomendaciones son:");
                  for (String[] string : recomendacionesHS) { 
                    for (String string2 : string) {
                      System.out.println(string2);
                    }    
                  }
                  sc.nextLine();
                  System.out.println("\nIngrese el estado que desea eliminar");
                  estado = sc.nextLine();

                  if (estado.equalsIgnoreCase("Malo")){
                    for (String string : maloHS) {
                      System.out.println(string);
                    }

                    System.out.println("\nIngrese el numero de recomendacion que quiere eliminar");
                    opcion = sc.nextInt();

                    maloHS[(opcion + 2)] =null;
                    
                    System.out.println("Las recomendaciones actualizadas son:");
                    for (String string : maloHS) {
                      if (string != null)
                      System.out.println(string);
                    }
                    sc.nextLine();
                    main(args);
                  }

                  if (estado.equalsIgnoreCase("Regular")){
                    for (String string : regularHS) {
                      System.out.println(string);
                    }

                    System.out.println("\nIngrese el numero de recomendacion que quiere eliminar");
                    opcion = sc.nextInt();

                    regularHS[(opcion + 2)] =null;
                    
                    System.out.println("Las recomendaciones actualizadas son:");
                    for (String string : regularHS) {
                      if (string != null)
                      System.out.println(string);
                    }
                    sc.nextLine();
                    main(args);
                  }

                  if (estado.equalsIgnoreCase("Bien")){
                    for (String string : buenoHS) {
                      System.out.println(string);
                    }

                    System.out.println("\nIngrese el numero de recomendacion que quiere eliminar");
                    opcion = sc.nextInt();

                    buenoHS[(opcion + 2)] =null;
                    
                    System.out.println("Las recomendaciones actualizadas son:");
                    for (String string : buenoHS) {
                      if (string != null)
                      System.out.println(string);
                    }
                    sc.nextLine();
                    main(args);
                  }
                  case 3: 
                  break;
                  }
                break;
              }
            break;
          }
        } else {
            System.out.println ("El correo no coincide");
          }
        } else {
          System.out.println ("Ingrese un rol valido");
        }
        
  }

  public static void crearUsuarioEstudiante(String name, int age){
    Estudiante E1 = new Estudiante();
    E1.setNombre(name);
    E1.setEdad(age);
  }

  public static void crearUsuarioAdministrador(String correoInst){
    Administrador A1 = new Administrador();
    A1.setCorreoInst(correoInst);
  }
}
